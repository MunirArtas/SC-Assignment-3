/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class problem4 {
    public void work(){
        Scanner input =new Scanner(System.in);
        //////////////////////////////////////////////////////////////////        
        System.out.print("Enter a number: ");
        //////////////////////////////////////////////////////////////////
        int x=input.nextInt();
        //////////////////////////////////////////////////////////////////
        System.out.print("Hailstone sequence: "+x+" ");
        while(x!=1){
            if(x%2==0){
                x=x/2;
            }else{
                x=(3*x)+1;
            }
            //////////////////////////////////////////////////////////////
            System.out.print(x+" ");
            //////////////////////////////////////////////////////////////
        } 
        //////////////////////////////////////////////////////////////////
    }
}

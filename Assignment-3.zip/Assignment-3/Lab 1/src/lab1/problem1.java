/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class problem1 {
    public void work(){
        ///////////////////////////////////////////////////////////////////
        Scanner input=new Scanner(System.in);
        ///////////////////////////////////////////////////////////////////
        System.out.print("how many numbers you want to add up: ");
        int y=input.nextInt();
        int [] x=new int [y];
        ///////////////////////////////////////////////////////////////////
        for (int i = 0; i < x.length; i++) {
            System.out.print("Enter number "+(i+1)+": ");
            x[i]=input.nextInt();
        }
        ///////////////////////////////////////////////////////////////////
        int z=0;
        for (int i = 0; i < x.length; i++) {
            z=z+x[i];
        }
        ///////////////////////////////////////////////////////////////////
        System.out.println("The sum of numbers Entered: "+z);
        /////////////////////////////////////////////////////////////////// 
    }
}

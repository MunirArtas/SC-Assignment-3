/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author fa16-bse-173
 */
public class Program {
        public static void main(String[] args) {
            //////////////////////////////////////////////////////////////////
            //problem1 p1=new problem1();p1.work();
            //////////////////////////////////////////////////////////////////
            //problem2 p2=new problem2();p2.work();
            //////////////////////////////////////////////////////////////////
            //problem3 p3=new problem3();p3.work();
            //////////////////////////////////////////////////////////////////
            //problem4 p4=new problem4();p4.work();
            //////////////////////////////////////////////////////////////////
            //problem5 p5=new problem5();p5.work();
            //////////////////////////////////////////////////////////////////
        }
}

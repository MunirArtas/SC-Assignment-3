package Lab5Adapter;

public interface MovableAdapter {
	public double getSpeed();

}

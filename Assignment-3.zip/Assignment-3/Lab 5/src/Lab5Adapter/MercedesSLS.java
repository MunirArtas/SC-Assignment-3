package Lab5Adapter;

public class MercedesSLS implements Movable {
	public double getSpeed() {
        return 265;
    }
}
package Lab5Adapter;

public class PeganiHuera implements Movable {
	public double getSpeed() {
        return 260;
    }

}

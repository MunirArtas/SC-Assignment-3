package Lab5Adapter;

public class Client {
	public static void main(String [] args){
		Movable m;
		m=new PeganiHuera();
		System.out.println(m.getSpeed());
		m=new MercedesSLS();
		System.out.println(m.getSpeed());
	}
}

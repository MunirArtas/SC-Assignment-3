package Lab5Facade;

public class Blackberry implements MobileShop {  
    @Override  
    public void modelNo() {  
    System.out.println(" Blackberry k40 ");  
    }  
    @Override  
    public void price() {  
        System.out.println(" Rs 125000.00 ");  
    }  
}

package Lab5Facade;

public class Samsung implements MobileShop {  
    @Override  
    public void modelNo() {  
    System.out.println(" Samsung note 11 ");  
    }  
    @Override  
    public void price() {  
        System.out.println(" Rs 245000.00 ");  
    }  
}  
package Lab5Builder;

public abstract class Company extends CD{  
	   public abstract int Price();  
}  

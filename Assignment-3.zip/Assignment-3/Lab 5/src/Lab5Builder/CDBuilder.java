package Lab5Builder;

public class CDBuilder {
	public CDtype buildSonyCD(){   
		CDtype cds=new CDtype();  
        cds.addItem(new Sony());  
        return cds;  
        }  
	public CDtype buildSamsungCD(){  
		CDtype cds=new CDtype();  
		cds.addItem(new Samsung());  
		return cds;  
		}  

}

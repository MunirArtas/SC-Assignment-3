package Lab5Builder;

public class Samsung extends Company{  
	
	@ Override public int Price(){   
		return 150;  
    }  
    @Override public String Pack(){  
    	return "Samsung CD";  
    }
}

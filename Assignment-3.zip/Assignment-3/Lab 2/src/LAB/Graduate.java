/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB;

/**
 *
 * @author fa16-bse-173
 */
public class Graduate extends Student{
    Graduate(String name){
        super(name);
        for (int i = 0; i < test; i++) {
            System.out.print("Enter Test "+(1+i)+" Scores: ");
            TestResults[i]=input.nextInt();
        }
        System.out.println("");
    }
@Override public String getCoursegrade(){
        int total=0;
        for (int i = 0; i < TestResults.length; i++) {
            total+=getTestResults(i+1);
        }
        if(total>80){
            return "Pass";
        }else{
            return "Fail";
        }
    }
       
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB;

import java.util.Scanner;

/**
 *
 * @author fa16-bse-173
 */
public class Program {
    
    public static void main(String [] args){
        //////////////////////////////////////////////////
        Scanner input=new Scanner(System.in);
        //////////////////////////////////////////////////
        Student std[]=new Student[40];
        String names="";
        String Status="";
        //////////////////////////////////////////////////
        System.out.print("Enter number of Students:");
        int noofstd=input.nextInt();
        //////////////////////////////////////////////////
        for (int i = 0; i < noofstd ; i++) {
                    System.out.print("Enter Student name: ");
                    names=input.next();
                    //////////////////////////////////////////////////
                    System.out.print("Enter Student's Accadamic Status (Graduate/Undergraduate): ");
                    Status=input.next();
                    if(Status.equalsIgnoreCase("Undergraduate")||Status.equalsIgnoreCase("U")){
                        std[i]=new UnderGraduate(names);
                    }else{
                        std[i]=new Graduate(names);
                    }
            
        }
        //////////////////////////////////////////////////
        for (int i = 0; i < noofstd; i++) {
           System.out.println(std[i].getName()+"'s Grade: "+std[i].getCoursegrade()); 
        }
        /////////////////////////////////////////////////
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab;
import java.util.*;
/**
 *
 * @author fa16-bse-173
 */
public class FactoryPattern {
    public static void main(String [] args){
        ///////////////////////////////////////////////////////////
        Scanner input=new Scanner(System.in);
        ShapeFactory ShapeGetter=new ShapeFactory();
        ///////////////////////////////////////////////////////////
        System.out.print("Enter the Shape:");
        String shape=input.next();
        ///////////////////////////////////////////////////////////
        Shape S=ShapeGetter.getshape(shape);
        S.draw();
    }
}
